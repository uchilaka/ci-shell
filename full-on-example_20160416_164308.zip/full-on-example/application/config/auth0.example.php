<?php
/** @TOTO update this configuration file with your Auth0 Credentials
 * You can signup for Auth0 at http://auth0.com
 */

$config['auth0'] = [
    'domain' => 'your.auth0.domain.com',
    'client_id' => '<Your Auth0 Client ID>',
    'secret' => '<Your Auth0 Client Secret>'
];


