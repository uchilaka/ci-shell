<?php

function getAuth0Config() {
    return [
        'domain' => 'wptest.auth0.com',
        'client_id' => 'KNuydwEqwGsPNpxdAhACmOWDUmBEZsLn',
        'client_secret' => 'cQT57M1wIYvcW1Rr6lTGWitqlkBtYwsyYkHG-mhVKdxhXBATWDwM6tB0mJFJVWFv',
        'redirect_uri' => 'http://localhost:3000/index.php',
    ];
}