<?php

$config['auth0'] = [
    'domain' => 'larcity.auth0.com',
    'client_id' => 'RVO8DKFWLyuajxzgisaY14VRTcZfuuTK',
    'secret' => 'GcfK84BdmLsruxmYtHHZaP3-xo_C-QKsnonyqtOU4wGpLFRI9ZVMHBFmjLIiXw5U',
    'api_uri' => 'https://larcity.auth0.com/'
];


