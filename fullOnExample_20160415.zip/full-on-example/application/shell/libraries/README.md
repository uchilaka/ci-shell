## Here's some notes on OAuth2

Please review [Bshaffer's great blog](http://bshaffer.github.io/oauth2-server-php-docs/cookbook/) on implementing OAuth2 for your project. You won't regret you did... mostly 
because this project uses his library :)