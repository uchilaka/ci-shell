<a href="?logout">Logout</a>
<a href="?update-metadata">Update Metadata</a>
<a href="?create-user">Create User</a>


<?php
dd($userInfo);
