<?php
/**
 * Created by PhpStorm.
 * User: germanlena
 * Date: 4/23/15
 * Time: 12:03 PM
 */

namespace Auth0\SDK\Exception;

/**
 * Represents all errors returned by the server
 *
 * @author Auth0
 */
class ApiException extends \Exception {

}